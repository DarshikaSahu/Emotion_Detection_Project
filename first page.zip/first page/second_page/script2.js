function toggleOption(option) {
    document.getElementById('image-section').classList.add('hidden');
    document.getElementById('text-section').classList.add('hidden');
    document.getElementById('speech-section').classList.add('hidden');
    document.getElementById(option + '-section').classList.remove('hidden');
}

function detectEmotion() {
    alert("Emotion Detection Started!");
}

function analyzeTextSentiment() {
    let text = document.getElementById("textInput").value;
    alert("Analyzing Sentiment: " + text);
}

function startSpeechRecognition() {
    let speechResult = document.getElementById("speechResult");
    let recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.onstart = function() {
        speechResult.innerText = "Listening...";
    };
    recognition.onspeechend = function() {
        recognition.stop();
        speechResult.innerText = "Processing...";
    };
    recognition.onresult = function(event) {
        let transcript = event.results[0][0].transcript;
        speechResult.innerText = "Detected Speech: " + transcript;
    };
    recognition.start();
}